/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
package com.mycompany.log;
import java.lang.Math.*;
public class Simple {
    public static double calSimple(double amt,double price,double year)
    {
        return (amt*price*year)/100;
    }
    public static double calCompound(double amt,double price,double time)
    {
        return amt*Math.pow((1+price/12),time);
    }
}
