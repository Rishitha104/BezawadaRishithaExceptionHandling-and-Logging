/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author HP
 */
import org.apache.logging.log4j.*;
import java.util.*;
import com.mycompany.log.*;
public class NewMain {

    /**
     * @param args the command line arguments
     */
    private static final Logger LOGGER=LogManager.getLogger(NewMain.class);
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc=new Scanner(System.in);
        LOGGER.info("enter values");
        String mat=sc.nextLine();
        int total=sc.nextInt();
        boolean auto=sc.nextBoolean();
        LOGGER.info(Pricing.calPrice(mat, total, auto));
    }
    
}
